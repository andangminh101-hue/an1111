# Gold Tower Defense Server (starter)

Bộ khung backend cho game Tower Defense tự làm. Bao gồm tài khoản, lưu dữ liệu SQLite, bảng xếp hạng realtime qua Socket.IO và trang quản trị.

## Yêu cầu
- Node.js 20 trở lên
- Máy tính hoặc hosting hỗ trợ ứng dụng Node.js và lưu trữ đĩa bền vững

## Chạy trên máy tính
1. Giải nén thư mục.
2. Mở terminal trong thư mục này và chạy `npm install`.
3. Sao chép `.env.example` thành `.env`.
4. Thay `SESSION_SECRET` bằng chuỗi ngẫu nhiên dài ít nhất 32 ký tự và đặt `ADMIN_PASSWORD` thành mật khẩu riêng dài ít nhất 12 ký tự.
5. Chạy `npm start`.
6. Mở `http://localhost:3000`; trang quản trị tại `http://localhost:3000/admin`.

Không đưa file `.env` lên GitHub và không dùng mật khẩu mẫu khi triển khai online.

## API
- `GET /api/health` — kiểm tra server.
- `POST /api/register` — JSON `{ "username":"player_1", "password":"your-password" }`
- `POST /api/login` — cùng cấu trúc.
- `POST /api/logout`
- `GET /api/me` — cần đăng nhập.
- `GET /api/leaderboard`
- `POST /api/game/result` — cần đăng nhập; JSON `{ "won": true, "score": 250 }`
- `POST /api/admin/login` — JSON `{ "username":"admin", "password":"mật-khẩu-trong-env" }`
- `GET /api/admin/players` — cần phiên quản trị.
- `POST /api/admin/players/:id/ban` — JSON `{ "banned": true }` hoặc `false`.

Các request đăng nhập cần giữ cookie session. Frontend mẫu đã xử lý cookie tự động cùng origin.

## Quan trọng trước khi đưa game thật lên mạng
Đây là **bản khởi đầu**, chưa phải backend chống gian lận hoàn chỉnh. Endpoint kết quả trận hiện nhận điểm từ client để minh họa; người chơi có thể giả mạo điểm nếu triển khai nguyên trạng. Với game thật, cần chuyển logic trận đấu sang server-authoritative: server tự mô phỏng/kiểm tra wave, sát thương, thắng thua và phần thưởng; client không được tự gửi số vàng/XP/điểm đáng tin cậy. Nên bổ sung HTTPS, sao lưu database, kiểm tra đầu vào, CSRF protection phù hợp với cách triển khai, logging và giới hạn quyền quản trị. Nếu dùng nhiều máy chủ, cần thay SQLite session store bằng session store dùng chung.


## Deploy lên Render (bản thử nghiệm)
1. Đưa toàn bộ mã nguồn lên một repository GitHub.
2. Trong Render, chọn **New → Web Service** và kết nối repository.
3. Chọn lệnh build `npm install`, lệnh chạy `npm start`.
4. Thêm biến môi trường `SESSION_SECRET` (chuỗi ngẫu nhiên dài ít nhất 32 ký tự), `ADMIN_USERNAME`, `ADMIN_PASSWORD` (mật khẩu riêng dài ít nhất 12 ký tự) và `NODE_ENV=production`.
5. Deploy rồi mở URL `onrender.com` mà Render cấp.

**Lưu ý dữ liệu:** Render Free dùng filesystem tạm thời; SQLite và session file có thể mất khi restart/redeploy/sleep. Đừng dùng cấu hình SQLite này để lưu dữ liệu người chơi quan trọng trên Render Free. Để giữ dữ liệu, hãy dùng database bền vững (ví dụ PostgreSQL) và sửa backend để dùng PostgreSQL, hoặc chọn dịch vụ có persistent volume và đặt `DATA_DIR` bên trong đường dẫn volume đã mount. Persistent disk của Render chỉ có trên dịch vụ trả phí.

## Cách tích hợp game web
- Dùng `fetch('/api/register', ...)`, `fetch('/api/login', ...)` và `fetch('/api/me')` khi game được phục vụ cùng domain với server.
- Dùng Socket.IO client để nghe sự kiện `leaderboard:update`.
- Không lưu mật khẩu trong trình duyệt và không đặt bí mật quản trị trong JavaScript phía client.
- Không tin điểm, vàng, XP hoặc kết quả trận do trình duyệt gửi lên. Trước khi mở công khai, cần đưa logic xác minh trận đấu lên server và chỉ để server quyết định phần thưởng.
